#ifndef _ALLHEROS_H_
#define _ALLHEROS_H_
#include "hero/hero.h"
#include "hero/tfns.h"
#include "hero/mlps.h"
#include "hero/ltzz.h"
#include "hero/bqzs.h"
#include "hero/yn.h"
#include "hero/qxsq.h"
#include "hero/snzx.h"
#include"hero/wlshz.h"
#include "hero/smallhero.h"
#endif